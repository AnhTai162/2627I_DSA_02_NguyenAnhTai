import java.util.Arrays;
import java.util.List;

public class CountingSort1 {

    public static int[] countingSort(List<Integer> arr) {
        // Mảng đếm kích thước 100 cho các giá trị từ 0 đến 99
        int[] frequency = new int[100];

        for (int num : arr) {
            if (num >= 0 && num < 100) {
                frequency[num]++;
            }
        }

        return frequency;
    }

    public static void main(String[] args) {
        List<Integer> testCase = Arrays.asList(1, 1, 3, 4, 99, 99);

        int[] result = countingSort(testCase);
        System.out.println("\nToàn bộ 100 phần tử kết quả:");
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + (i == result.length - 1 ? "" : " "));
        }
        System.out.println();
    }
}
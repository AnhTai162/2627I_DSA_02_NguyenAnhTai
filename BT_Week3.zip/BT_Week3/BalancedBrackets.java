import java.util.ArrayDeque;
import java.util.Deque;

public class BalancedBrackets {

    public static boolean isBalanced(String s) {
        if (s == null) {
            return false;
        }


        Deque<Character> stack = new ArrayDeque<>();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);


            if (c == '(' || c == '{' || c == '[') {
                stack.push(c);
            }

            else if (c == ')' || c == '}' || c == ']') {

                if (stack.isEmpty()) {
                    return false;
                }

                char top = stack.pop();


                if (c == ')' && top != '(') return false;
                if (c == '}' && top != '{') return false;
                if (c == ']' && top != '[') return false;
            }
        }


        return stack.isEmpty();
    }

    public static void main(String[] args) {
        String[] testCases = {
                "{[()]}",
                "{[(])}",
                "{{[[(())]]}}",
                "((()",
                "())"
        };

        for (String test : testCases) {
            System.out.println(test + " -> " + (isBalanced(test) ? "YES" : "NO"));
        }
    }
}
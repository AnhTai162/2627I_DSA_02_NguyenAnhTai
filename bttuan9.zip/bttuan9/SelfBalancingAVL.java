package bttuan9;

public class SelfBalancingAVL {
    static class Node {
        int val;
        int ht;
        Node left;
        Node right;

        Node(int val) {
            this.val = val;
            this.ht = 0;
        }
    }

    private static int height(Node node) {
        return (node == null) ? -1 : node.ht;
    }

    private static int getBalance(Node node) {
        return (node == null) ? 0 : height(node.left) - height(node.right);
    }

    private static Node rightRotate(Node y) {
        Node x = y.left;
        Node t2 = x.right;

        x.right = y;
        y.left = t2;

        y.ht = 1 + Math.max(height(y.left), height(y.right));
        x.ht = 1 + Math.max(height(x.left), height(x.right));

        return x;
    }

    private static Node leftRotate(Node x) {
        Node y = x.right;
        Node t2 = y.left;

        y.left = x;
        x.right = t2;

        x.ht = 1 + Math.max(height(x.left), height(x.right));
        y.ht = 1 + Math.max(height(y.left), height(y.right));

        return y;
    }

    public static Node insert(Node root, int val) {
        if (root == null) {
            return new Node(val);
        }

        if (val < root.val) {
            root.left = insert(root.left, val);
        } else if (val > root.val) {
            root.right = insert(root.right, val);
        } else {
            return root;
        }

        root.ht = 1 + Math.max(height(root.left), height(root.right));
        int balance = getBalance(root);

        if (balance > 1 && val < root.left.val) {
            return rightRotate(root);
        }
        if (balance < -1 && val > root.right.val) {
            return leftRotate(root);
        }
        if (balance > 1 && val > root.left.val) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }
        if (balance < -1 && val < root.right.val) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }

    public static void printPreOrder(Node root) {
        if (root == null) return;
        System.out.print(root.val + " ");
        printPreOrder(root.left);
        printPreOrder(root.right);
    }

    public static void main(String[] args) {
        Node root = null;
        int[] vals = {3, 2, 4, 5, 6};
        for (int v : vals) {
            root = insert(root, v);
        }

        printPreOrder(root);
        System.out.println();
    }
}
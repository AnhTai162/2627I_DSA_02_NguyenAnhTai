

import java.util.Arrays;

public class GeneralTreeArray {
    static class Tree {
        int[] data;
        int[] firstChild;
        int[] nextSibling;
        int size;

        public Tree(int capacity) {
            data = new int[capacity];
            firstChild = new int[capacity];
            nextSibling = new int[capacity];
            Arrays.fill(firstChild, -1);
            Arrays.fill(nextSibling, -1);
            size = 0;
        }

        public int addRoot(int val) {
            data[0] = val;
            size = 1;
            return 0;
        }

        public int addChild(int parent, int val) {
            int newIdx = size++;
            data[newIdx] = val;

            if (firstChild[parent] == -1) {
                firstChild[parent] = newIdx;
            } else {
                int curr = firstChild[parent];
                while (nextSibling[curr] != -1) {
                    curr = nextSibling[curr];
                }
                nextSibling[curr] = newIdx;
            }
            return newIdx;
        }

        public void printPreOrder(int node, int depth) {
            if (node == -1) return;
            for (int i = 0; i < depth; i++) System.out.print("  ");
            System.out.println("- " + data[node] + " (Index: " + node + ")");

            int child = firstChild[node];
            while (child != -1) {
                printPreOrder(child, depth + 1);
                child = nextSibling[child];
            }
        }
    }

    public static void main(String[] args) {
        Tree tree = new Tree(10);
        int r = tree.addRoot(1);
        int c1 = tree.addChild(r, 2);
        int c2 = tree.addChild(r, 3);
        int c3 = tree.addChild(r, 4);
        tree.addChild(c1, 5);
        tree.addChild(c1, 6);

        tree.printPreOrder(0, 0);
    }
}
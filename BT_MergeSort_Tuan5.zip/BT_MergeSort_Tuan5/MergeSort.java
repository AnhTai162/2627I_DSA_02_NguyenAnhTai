import java.util.Arrays;

public class MergeSort {

    private static int step = 1;

    public static void sort(int[] a) {
        int[] aux = new int[a.length];
        sort(a, aux, 0, a.length - 1);
    }

    private static void sort(int[] a, int[] aux, int low, int high) {
        if (high <= low) return;

        int mid = low + (high - low) / 2;

        sort(a, aux, low, mid);
        sort(a, aux, mid + 1, high);

        merge(a, aux, low, mid, high);
    }

    private static void merge(int[] a, int[] aux, int low, int mid, int high) {
        for (int k = low; k <= high; k++) {
            aux[k] = a[k];
        }

        int i = low;
        int j = mid + 1;

        for (int k = low; k <= high; k++) {
            if (i > mid) {
                a[k] = aux[j++];
            } else if (j > high) {
                a[k] = aux[i++];
            } else if (aux[j] < aux[i]) {
                a[k] = aux[j++];
            } else {
                a[k] = aux[i++];
            }
        }

        System.out.printf("Bước %d [Trộn đoạn %d -> %d]: %s%n",
                step++, low, high, Arrays.toString(a));
    }

    public static void main(String[] args) {
        int[] arr = {38, 27, 43, 3, 9, 82, 10};

        System.out.println("Mảng ban đầu: " + Arrays.toString(arr));
        System.out.println("--------------------------------------------------");

        sort(arr);

        System.out.println("--------------------------------------------------");
        System.out.println("Kết quả sau khi sắp xếp: " + Arrays.toString(arr));
    }
}